<?php
define ("PATH", "/home/franj/projects/omi/web/");
define ("URL", "http://omi.local/");
define ("PORT_SOCKET", "8888");

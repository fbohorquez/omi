<?php
function start ($data = []) {
   session_start ();
} 

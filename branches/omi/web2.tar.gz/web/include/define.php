<?php
define ("PATH", "/home/franj/projects/omi/web/");
define ("URL", "http://omi.local/");
//~ define ("URL", "http://192.168.1.15/");
define ("PORT_SOCKET", "8888");

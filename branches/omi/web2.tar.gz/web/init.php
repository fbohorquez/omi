<?php
include ('include/define.php');
include ('include/functions.php');

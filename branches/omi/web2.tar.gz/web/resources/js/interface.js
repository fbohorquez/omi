var editor = CodeMirror.fromTextArea(document.getElementById("code"), {
   lineNumbers: true,
   matchBrackets: true,
   mode: "text/x-omi",
});

editor_height = editor.getScrollInfo().height;

editor.on("scroll", function () {
   (editor.getScrollInfo().height == editor_height) 
      && $("#source-send").css('right', '10px') 
      || $("#source-send").css('right', '20px');
});

$("#symbols-drawing")[0].width = $("#symbols-container").width();
$("#symbols-info")[0].width = $("#symbols-container").width();
$("#tree-drawing")[0].width = $("#tree").width();
$("#info-drawing")[0].width = $("#tree").width();
$("#info-drawing")[0].width = $("#tree").width();
$("#console_omi-graph-drawing")[0].width = $("#console_omi-graph").width() - 15;
editor.focus();

function output (str) {
   $("#output-terminal-01").html($("#output-terminal-01").html() + str);
   var div= document.getElementById('output-terminal-01');
   var hasVerticalScrollbar= div.scrollHeight>div.clientHeight
   $("#source-out-clean").css('right', (hasVerticalScrollbar)?27:15);
}

function output_clear () {
   $("#output-terminal-01").html("");
   var div= document.getElementById('output-terminal-01');
   var hasVerticalScrollbar= div.scrollHeight>div.clientHeight
   $("#source-out-clean").css('right', (hasVerticalScrollbar)?27:15);
}

function input (cb) {
   var str = "";
   function keyDownTextField(e) {
      if ($("#tab-out").hasClass('tab-active')){
         var keyCode = e.keyCode;
         if(keyCode==13) {
            document.removeEventListener("keydown", keyDownTextField);
            $("#output-terminal-01").html($("#output-terminal-01").html() + "<br/>");
            cb (str);
         } else {
            str += String.fromCharCode(keyCode);
            $("#output-terminal-01").html($("#output-terminal-01").html() + String.fromCharCode(keyCode));
         }
      }
   }
   document.addEventListener("keydown", keyDownTextField, false);
}

var select_symbols = [];
function selectTableSimbols (table, key, name, noselect, level) {
    
   if (table){
      level = level || table.current_level;
      table.current_level = level;
   }
   if (table) table.draw();
   $("#symbols .tab").removeClass ('tab-active');
   switch (key) {
      case 'Vars': 
      case 'vars': 
         $("#symbols-vars-tab").addClass ('tab-active');
         name = 'Vars';
      break;
      case 'Functions': 
      case 'Funcs': 
      case 'funcs': 
         $("#symbols-funcs-tab").addClass ('tab-active');
         name = 'Functions';
      break;
      case 'Class': 
      case 'class': 
         $("#symbols-class-tab").addClass ('tab-active');
         name = 'Class';
      break;
   }
   if (!noselect)
      select_symbols = [{'name': name, 'table' : table, 'level' : level}];
   $("#symbols-navegate-title").html(name + ((level)?' (level:' + level +')':''));
   $('#symbols-menu').hide();
   if (symbols.omi)
      symbols.omi.table_use = table;
}
function printSelectSimbols () {
   if ($('#symbols-menu:visible').length == 0){
      var str = "";
      for (i = 0, n = select_symbols.length; i < n; ++i){
         for (var j = select_symbols[i].table.refs.length - 1; j >= 0; --j){ 
            str += '<p class="symbols-menu-item" ><a href="#" onclick="selectSymbol(\'' + select_symbols[i].name + '\', ' + j + ');return false;" >' + select_symbols[i].name + ((j != 0)?' (level: ' + j + ')':'') + '</a></p>';
         }
      }
      $("#symbols-menu-items").html(str);
      $('#symbols-menu').show();
   }else{
      $('#symbols-menu').hide();
   }
}

function selectSymbol (key, level) {
   while (select_symbols.length){
      if (select_symbols[0].name == key && select_symbols[0].table) {
         selectTableSimbols(select_symbols[0].table, select_symbols[0].name, select_symbols[0].name, true, level);
         break;
      }
      else {
         select_symbols.shift();
      }
   }
   //~ $("#symbols-navegate-title").html(key);
   $('#symbols-menu').hide();
}

function clearInterface ()  {
   $('#symbols-menu').hide();
   selectTableSimbols (null, 'vars');
   if (console_omi.omi) console_omi.omi.clear();
}

function isNodeClick (node) {
   if (node) {
      document.body.style.cursor = 'pointer';
   }
   else {
      document.body.style.cursor = 'default';
   }
}

function offStep (){
   $("#control-play").addClass('disable');
   $("#control-pause").addClass('disable');
   $("#control-step").addClass('disable');
   $("#control-stmt").addClass('disable');
}

function onStep (){
   $("#control-play").removeClass('disable');
   $("#control-pause").removeClass('disable');
   $("#control-step").removeClass('disable');
   $("#control-stmt").removeClass('disable');
}

function endStep (){
   tree.stop_play ();
   $("#control-reset").show();
   $("#control-play").hide();
   $("#control-pause").hide();
   $("#control-reset").removeClass('disable');
   $("#control-step").addClass('disable');
   $("#control-stmt").addClass('disable');
}

function resetStep (){
   $("#control-reset").hide();
   $("#control-play").show();
   $("#control-pause").hide();
   send();
}

function activeSrc() {
   $('#output-01').hide();
   $('#source-01').show();
   $('.tab-inout').removeClass('tab-active');
   $("#tab-src").addClass('tab-active');
   $('#inout-title').html('Source<span title=\"Código fuente\" class=\"help\"><i class=\"fa fa-question-circle\"></i></span>');
}

function activeIO() {
   $('#source-01').hide();
   $('#output-01').show();
   $('.tab-inout').removeClass('tab-active');
   $("#tab-out").addClass('tab-active');
   $('#inout-title').html('Input/Output<span title=\"Interfaz de entrada/salida\" class=\"help\"><i class=\"fa fa-question-circle\"></i></span>');
}


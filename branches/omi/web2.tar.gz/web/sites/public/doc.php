<?php
include ('../../init.php');
template::header (['css' => 'latex']);
template::menuMobile ();
template::top ();
template::doc ();
template::footer ();
?>





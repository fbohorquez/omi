<?php
include ('../../init.php');
template::header ();
template::menuMobile ();
template::imgHead();
template::content ();
template::footer ();
?>





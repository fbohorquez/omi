<?php
include ('../../init.php');
?>
<html>   
<head>
      <link href='https://fonts.googleapis.com/css?family=Dosis:700,500' rel='stylesheet' type='text/css'>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
      <link href="<?=URL;?>src/vendor/codemirror/lib/codemirror.css" rel="stylesheet" type="text/css" />
      <link href="<?=URL;?>src/vendor/codemirror/theme/yeti.css" rel="stylesheet" type="text/css" />
      <link href="<?=URL;?>src/css/main.css" rel="stylesheet" type="text/css" />
      <link href="<?=URL;?>src/css/client.css" rel="stylesheet" type="text/css" />
</head>
<body>
   <?php template::top(); ?>
   <div id="content">
      <form id="rtree" >
   <div id="tree-container">
      <div class="buttons">
         <p id="tree-title" class="title" >
            Run tree
         </p>
      </div>
      <div id="tree">
       <canvas id="tree-drawing" width="1000" height="" 
         style="position: absolute; left: 20; top: 20; z-index: 0;"></canvas>
       <canvas id="info-drawing" width="1000" height="" 
         style="position: absolute; left: 20; top: 20; z-index: 1;"></canvas>
      </div>
   </div>
   <div id="symbols">
    <div class="buttons">
       <p id="symbols-title" class="title" >
            Symbols tables
       </p>
       <a href="#" id="symbols-vars-tab" class="tab tab-active" onclick="selectTableSimbols(symbols.omi && symbols.omi.tables.vars, 'vars','vars', null, symbols.omi && symbols.omi.tables.vars.current_level); return false;">Vars</a>
       <a href="#" id="symbols-funcs-tab" class="tab" onclick="selectTableSimbols(symbols.omi && symbols.omi.tables.funcs, 'funcs'); return false;">Functions</a>
       <a href="#" id="symbols-class-tab" class="tab" onclick="selectTableSimbols(symbols.omi &&  symbols.omi.tables.class, 'class'); return false;">Class</a>
    </div>
    <div id="symbols-container">
      <canvas id="symbols-drawing" width="" height="" 
      style="position: absolute; left: 20; top: 20; z-index: 0;"></canvas>
      <canvas id="symbols-info" width="" height="" 
      style="position: absolute; left: 20; top: 20; z-index: 1;"></canvas>
      
    </div>
    <div style="right: 15px;" id="symbols-menu" onclick="return false;">
      <div id="symbols-menu-items"></div>
   </div>
    <button style="right: 15px;" id="symbols-navegate" onclick="printSelectSimbols();return false;"><i class="fa fa-table"></i> <span id="symbols-navegate-title">Vars</span></button>
   </div>
   <div id="inout">
    <div class="buttons">
      <p id="inout-title" class="title">
         SOURCE<span title="Código fuente" class="help"><i class="fa fa-question-circle"></i></span>
      </p>
      <a href="#" id="tab-src" class="tab tab-inout tab-active" onclick="activeSrc();return false;">Src</a>
       <a href="#" id="tab-out" class="tab tab-inout" onclick="activeIO();return false;">In/Out</a>
    </div>
    <div id="source-01" class="source">
      <textarea id="code" name="code"></textarea>
      <button id="source-send" title="Enviar código fuente (Shift+Enter)" onclick="send();$('#tab-out').click();output_clear();return false;" ><i class="fa fa-paper-plane"></i> Enviar </button>
    </div>
    <div id="output-01" class="output-container" style="display:none;">
      <div id="output-terminal-01" class="output"  ></div>
      <button id="source-out-clean" onclick="if(confirm('¿Realmente desea limpiar la salida?')) output_clear();return false;" ><i class="fa fa-trash-o"></i> Limpiar </button>
    </div>
    
   </div>
   <div id="console_omi">
      <div id="console_omi-info">
         <div id="console_omi-graph">
         <canvas id="console_omi-graph-drawing" width="546" height="160" 
            style="position: absolute; left: 0; top: 0; z-index: 1;"></canvas>
         </div>
         <div id="console_omi-txt">
            
         </div>
      </div>
      <div id="console_omi-data">
         <ul id="console_omi-list-value"></ul>
         <div id="controls">
            <a href="#" id="control-play" title="Ejecución automática (F5)" class="disable button" onclick="if (!$(this).hasClass('disable')) tree.run_play();return false;"><i class="fa fa-play"></i></a>
            <a href="#" id="control-reset" title="Repetir ejecución" class="button" onclick="if (!$(this).hasClass('disable')) resetStep();return false;" style="display:none;" ><i class="fa fa-repeat"></i></a>
            <a href="#" id="control-pause" title="Pausar ejecución automática (F5)" class="disable button" onclick="if (!$(this).hasClass('disable')) tree.stop_play();return false;" style="display:none;" ><i class="fa fa-pause"></i></a>
            <a href="#" id="control-step" title="Siguiente paso (F6)" class="disable button" onclick="if (!$(this).hasClass('disable')) tree.run_next();return false;"><i class="fa fa-step-forward"></i></a>
            <a href="#" id="control-stmt" title="Siguiente sentencia (F7)" class="disable button" onclick="if (!$(this).hasClass('disable')) tree.run_next_stmt(); return false;"  ><i class="fa fa-fast-forward"></i></a>
            <a href="#" id="control-file" class="button" style="font-size: 22px;padding: 7px 7px;" ><i class="fa fa-file-code-o"></i></a>
            <a href="#" id="control-save" class="button" style="font-size: 22px;padding: 7px 7px;" ><i class="fa fa-floppy-o"></i></a>
         </div>
      </div>
   </div>
   </form>
</div>
<!--
<input type="button" value="Next" >
      <input type="button" value="Send" onclick="send();">
-->
<div id="footer">
   GPLv3
</div>
<script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<script type="text/javascript" src="<?=URL;?>src/js/omi.tree.js"></script>
<script type="text/javascript" src="<?=URL;?>src/js/omi.node.js"></script>
<script type="text/javascript" src="<?=URL;?>src/js/omi.config.js"></script>
<script type="text/javascript" src="<?=URL;?>src/js/omi.extend.js"></script>

<script type="text/javascript" src="<?=URL;?>src/js/omi.symbols.js"></script>
<script type="text/javascript" src="<?=URL;?>src/js/omi.ref.js"></script>
<script type="text/javascript" src="<?=URL;?>src/js/omi.console.js"></script>
<script type="text/javascript" src="<?=URL;?>src/js/omi.clone.js"></script>
<script type="text/javascript" src="<?=URL;?>src/js/omi.run.js"></script>
<script type="text/javascript" src="<?=URL;?>src/vendor/codemirror/lib/codemirror.js"></script>
<script type="text/javascript" src="<?=URL;?>src/vendor/codemirror/mode/clike/clike.js"></script>
<script type="text/javascript" src="<?=URL;?>src/vendor/shortcut/shortcut.js"></script>
<script type="text/javascript" src="<?=URL;?>src/js/interface.js"></script>
<script> 
  
</script> 
 <script>
   clearInterface();
   console_omi.iDefault ();
   editor.focus();
   $( document ).tooltip();
   shortcut.add("F5",function() {
      if (tree.play){
         if (!$("#control-pause").hasClass('disable')) tree.stop_play();
      }else{
         if (!$("#control-play").hasClass('disable')) tree.run_play();
      }
   });
   shortcut.add("F6",function() {
      if (!$("#control-step").hasClass('disable')) tree.run_next();
   });
   shortcut.add("F7",function() {
      if (!$("#control-step").hasClass('disable')) tree.run_next_stmt();
   });
   shortcut.add("Shift+Enter",function() {
      send();
   });

</script>
</body>
</html>





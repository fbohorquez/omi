<div id="footer">
   GPLv3
</div>
<script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
</body>
</html>

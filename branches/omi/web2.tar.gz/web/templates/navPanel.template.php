<div id="<?=$param['id'];?>">
   <a href="<?=URL?>" class="nav">HOME</a>
   <a href="<?=URL?>doc-index.php" class="nav">DOCUMENTACIÓN</a>
   <a href="" class="nav">DESCARGAS</a>
   <a href="<?=URL?>rtree/" class="nav">RUNTREE</a>
</div>


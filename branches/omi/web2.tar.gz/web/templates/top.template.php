<div id="header">
   <img src="<?=URL?>src/images/logo.svg" height="60"/>
   <div id="header-border"></div>

<?php template::navPanel (['id' => 'nav-panel']);?>

</div>

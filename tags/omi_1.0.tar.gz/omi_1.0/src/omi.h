#ifndef NUMTYPE
#define NUMTYPE double
#endif

#ifndef NUMPRECISION
#define NUMPRECISION 15
#endif

#ifndef REFCTYPE
#define REFCTYPE unsigned int
#endif

#include "interpreter.h"
#include "plugin.h"
#include "run/tree/typeNode.h"

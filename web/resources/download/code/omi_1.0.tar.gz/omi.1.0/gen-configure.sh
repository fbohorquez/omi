libtoolize --force
aclocal
autoheader
automake --force-missing --add-missing  --copy
autoconf
#./configure
